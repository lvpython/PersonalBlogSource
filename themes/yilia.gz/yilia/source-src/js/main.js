require('./jquery')

var tags = require('./tags')
var archiveInner = require('./archive-inner')
var tools = require('./tools')
var browser = require('./browser')
var fixPage = require('./fix-page')
var mobile = require('./mobile')
var viewer = require('./viewer')
require('./jquery.lazyload')

$(function() {
	viewer.init()

	archiveInner.init()
	fixPage.init()
	tags.init()
	// todo: resize destrop
	if(browser.versions.mobile === true && $(window).width() < 800){
		mobile.init()
	}else{
		tools.init()
		$('.js-smart-menu').click(function(e) {
			e.stopPropagation()
			tools.show($(this).data('idx'))
		})
		$('.left-col,.mid-col').click(function() {
			tools.hide()
		})
		Vivus.init("vkki-logo", {
	            type: "delayed",
	            duration: 200,
	            animTimingFunction: Vivus.EASE_OUT
	        })

		$(".js-avatar").attr("src", $(".js-avatar").attr("lazy-src"));
		$(".js-avatar")[0].onload = function(){
			$(".js-avatar").addClass("show");
		}
		if(window.console && window.console.log) {
			console.log("红色是红色，那是因为你能看到红色。")
		}
	};


})
