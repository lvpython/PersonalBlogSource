var Util = require('./util')
var $article, $tools
var localKey = 'yilia-menu'
var $me = 0;
function triggerClk(idx) {
	$('.btn-wrap li').eq(idx).trigger('click')
}
function init() {
	// 变量初始化
	$article = $('.mid-col')
	$tools = $('.tools-col')

	// 切换
	$('.btn-wrap li').click(function() {
		var idx = $(this).index()
		window.localStorage.setItem(localKey, idx)
		$('.btn-wrap li').removeClass('chose')
		$(this).addClass('chose')
		$('.tools-section').removeClass('chose')
		$('.tools-wrap .tools-section').eq(idx).addClass('chose')
	})

	// 本地缓存
	var initIndex = parseInt(window.localStorage.getItem(localKey) || 0)
	triggerClk(initIndex)

	// about me
	var $about = $('.aboutme-wrap')
	var aboutStr = $about.html()
	$about.html(Util.decode(aboutStr))
}

function toggle() {
	$article.toggleClass('show')
	$tools.toggleClass('show')
}

function show(idx) {
	if (!$article.hasClass('show'))
	{
		triggerClk(idx)
		if (idx == 3) { $me++; }
		if ($me == 6) {
			$("#js-aboutme").text("首先你是对的");
		} else if ($me == 10) {
			$("#js-aboutme").text("你懂的");
		} else if ($me == 20) {
			$("#js-aboutme").text("再点就show佛法了");
		} else if ($me == 22) {
			window.location.reload();
		}

		$article.addClass('show')
		$tools.addClass('show')
	}
	else {
		hide();
	}
}

function hide() {
	$article.removeClass('show')
	$tools.removeClass('show')
}

module.exports = {
	init : init,
	toggle: toggle,
	show: show,
	hide: hide
}